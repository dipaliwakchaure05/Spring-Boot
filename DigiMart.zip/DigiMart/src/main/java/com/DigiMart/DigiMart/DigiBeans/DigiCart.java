package com.DigiMart.DigiMart.DigiBeans;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Component;



@Component
public class DigiCart {

	@Autowired
	private DigiProduct prod_name;
	private DigiCustomer Customer_name;
	
	public DigiCart() {
		super();
	System.out.println("DigiCart initialized......");
}

	public DigiProduct getproduct_name() {
		return prod_name;
	}
	
	public DigiCustomer getCustomer_name() {
		return Customer_name;
	}
	
}
