package com.DigiMart.DigiMart.DigiBeans;

import org.springframework.stereotype.Component;

import org.springframework.beans.factory.annotation.Autowired;


@Component
public class DigiCustomer {

	@Autowired
	private DigiProduct prod_name;
	
	
	
	public DigiCustomer() {
		super();
		System.out.println("Customer Has been Added......");
	}
	private String Cust_Name;
	public DigiCustomer(String Cust_Name) {
		this.Cust_Name = Cust_Name;
		System.out.println("Customer Name:" + Cust_Name);
	}
        public String getCust_name() {
		return Cust_Name;
	}
	public DigiProduct getCustomer_product() {
	return prod_name;
}
	
}
