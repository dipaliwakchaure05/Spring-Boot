package com.DigiMart.DigiMart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

@SpringBootApplication
public class DigiMartApplication {

	public static void main(String[] args) {
		SpringApplication.run(DigiMartApplication.class, args);
		try (AnnotationConfigApplicationContext ctx = new AnnotationConfigApplicationContext()) {
			ctx.register(DigiConfig.class);

			   ctx.refresh();
		}
	}

}
